﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication4.Models
{
    public class regmodel
    {
        public string Surname { get; set; } = "Фамилия";
        public string Name { get; set; } = "Имя";
        public string Secondname { get; set; } = "Отчество";
        public string Email { get; set; } = "Отчество";
        public string Phone { get; set; } = "Отчество";
    }
}