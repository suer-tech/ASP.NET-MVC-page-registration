﻿using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using WebApplication4.Models;
using WebApplication5.Models;
using System.Numerics;
using System.Xml.Linq;
using System.Text;

namespace WebApplication4.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private readonly IConfiguration _config;
        public HomeController(ILogger<HomeController> logger, IConfiguration config)
        {
            _logger = logger;

            _config = config;
        }

        public IDbConnection Connection
        {
            get
            {
                return new SqlConnection(_config.GetConnectionString("DefaultConnection"));
                Connection.Open();
               
            }
            
        }


        void button_click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [regDB] (Surname,Name,Secondname,Email,Phone) VALUES (@Surname, @Name, @Secondname, @Email, @Phone)");
        }


        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        public ActionResult Reg()
        {
            return View(new Models.regmodel());
        }


    }
     
}